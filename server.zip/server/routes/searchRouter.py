from fastapi import Depends, APIRouter
from database import get_db
from sqlalchemy.orm import Session
from models.room import Room
from controllers.searchController import SearchController

router = APIRouter(prefix="/search", tags=["Search"], responses={404: {"description": "Not found"}})

@router.get("/hotel/{address}")
def search_hotel_by_address(address: str, db: Session = Depends(get_db)):
    hotels = SearchController.search_hotel_by_address(address, db)
    return hotels

@router.get("/hotel/name/{hotel_name}")
def search_hotel_by_hotel_name(hotel_name: str, db: Session = Depends(get_db)):
    rooms = SearchController.search_hotel_by_hotel_name(hotel_name, db)
    return rooms

@router.get("/room/{room_name}")
def search_room_by_room_name(room_name: str, db: Session = Depends(get_db)):
    rooms = SearchController.search_room_by_room_name(room_name, db)
    return rooms

@router.get("/room/price/{max_price}")
def search_room_by_max_price(max_price: int, db: Session = Depends(get_db)):
    rooms = SearchController.search_room_by_max_price(max_price, db)
    return rooms

@router.get("/hotel/join")
def search_hotel_join_hotel_address_and_hotel_name(hotel_name: str, address: str, db: Session = Depends(get_db)):
    hotels = SearchController.search_hotel_join_hotel_address_and_hotel_name(hotel_name, address, db)
    return hotels

