from fastapi import Depends
from fastapi.responses import JSONResponse
from sqlalchemy import or_, and_
from sqlalchemy.orm import Session
from database import get_db
from models.room import Room
from models.hotel import Hotel

class SearchController:
    def search_hotel_by_address(address: str, db: Session = Depends(get_db)):
        hotels = db.query(Hotel).filter(Hotel.address.like(f"%{address}%")).all()
        return hotels
    
    def search_hotel_by_hotel_name(hotel_name: str, db: Session = Depends(get_db)):
        hotels = db.query(Hotel).filter(Hotel.name.like(f"%{hotel_name}%")).all()
        return hotels
    
    def search_room_by_room_name(room_name: str, db: Session = Depends(get_db)):
        rooms = db.query(Room).filter(Room.name.like(f"%{room_name}%")).all()
        return rooms
    
    def search_room_by_max_price(max_price: int, db: Session = Depends(get_db)):
        rooms = db.query(Room).filter(Room.price <= max_price).all()
        return rooms
    
    def search_hotel_join_hotel_address_and_hotel_name(hotel_name: str, address: str, db: Session = Depends(get_db)):
        hotels = db.query(Hotel).filter(and_(Hotel.name.like(f"%{hotel_name}%"), Hotel.address.like(f"%{address}%"))).all()
        return hotels